import {useEffect, useState} from 'react';
import {Card, ConfigProvider, Descriptions, List, Modal, Spin, Tag, Typography, message} from 'antd';
import Aside from "../components/Aside.jsx";
import {Prism as SyntaxHighlighter} from 'react-syntax-highlighter';
import {oneLight} from 'react-syntax-highlighter/dist/esm/styles/prism';
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';
import dayjs from 'dayjs';

const {Text} = Typography;

export default function Issues() {
    const [issues, setIssues] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedIssue, setSelectedIssue] = useState(null);
    const [isModalVisible, setIsModalVisible] = useState(false);

    useEffect(() => {
        fetchIssues();
    }, []);

    const fetchIssues = async () => {
        try {
            setLoading(true);
            // Замените URL на ваш реальный эндпоинт
            const response = await fetch('http://127.0.0.1:8006/api/issues');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            setIssues(data);
        } catch (error) {
            console.error('Error fetching issues:', error);
            message.error('Failed to load issues');
        } finally {
            setLoading(false);
        }
    };

    const handleIssueClick = (issue) => {
        setSelectedIssue(issue);
        setIsModalVisible(true);
    };

    const handleCloseModal = () => {
        setIsModalVisible(false);
        setSelectedIssue(null);
    };

    const getChartData = () => {
        const twoWeeksAgo = dayjs().subtract(14, 'day');
        const dayCounts = {};

        // Инициализация дней
        for (let i = 0; i < 14; i++) {
            const date = twoWeeksAgo.add(i, 'day').format('YYYY-MM-DD');
            dayCounts[date] = 0;
        }

        // Подсчет ошибок по дням
        issues.forEach(issue => {
            const date = dayjs(issue.timestamp).format('YYYY-MM-DD');
            if (dayCounts[date] !== undefined) {
                dayCounts[date]++;
            }
        });

        const dates = Object.keys(dayCounts).sort();
        const counts = dates.map(date => dayCounts[date]);

        return {
            dates,
            counts
        };
    };

    const {dates, counts} = getChartData();

    const chartOption = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            },
            formatter: (params) => {
                const date = params[0].axisValue;
                const count = params[0].data;
                return `${date}<br/>Ошибок: <b>${count}</b>`;
            }
        },
        grid: {
            left: '0',
            right: '0',
            top: '0',
            bottom: '0',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: dates.map(date => dayjs(date).format('DD.MM')),
            axisLabel: {
                color: '#666'
            },
            axisLine: {
                lineStyle: {
                    color: '#ddd'
                }
            },
            axisTick: {
                alignWithLabel: true
            }
        },
        yAxis: {
            show: false,
        },
        series: [{
            name: 'Ошибки',
            type: 'line',
            smooth: false,
            showSymbol: false,
            data: counts,
            areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    {offset: 0, color: 'rgba(138, 43, 226, 0.8)'},
                    {offset: 1, color: 'rgba(138, 43, 226, 0.1)'}
                ])
            },
            lineStyle: {
                width: 1,
                color: '#8A2BE2'
            },
        }]
    };

    const getSeverityColor = (severity) => {
        switch (severity) {
            case 'high':
                return 'red';
            case 'medium':
                return 'orange';
            case 'low':
                return 'green';
            default:
                return 'blue';
        }
    };

    return (
        <ConfigProvider
            theme={{
                token: {
                    colorPrimary: '#8A2BE2',
                    colorTextPlaceholder: '#777777',
                },
                components: {
                    Menu: {
                        darkItemSelectedBg: 'rgb(103,40,156)',
                    },
                    Button: {
                        defaultHoverBg: '#f6e6ff',
                        defaultHoverColor: '#8A2BE2',
                        defaultHoverBorderColor: '#8A2BE2',
                    },
                    Card: {
                        borderRadiusLG: 12,
                    },
                },
            }}
        >
            <div style={{display: 'flex', minHeight: '100vh', backgroundColor: '#f5f5f5'}}>
                <Aside/>
                <div style={{marginLeft: 350, padding: 24, width: '100%'}}>
                    <Card
                        style={{
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                            borderRadius: '12px',
                            marginBottom: 24,
                        }}
                    >
                        <ReactECharts
                            option={chartOption}
                            style={{height: 150}}
                            theme="light"
                            opts={{renderer: 'svg'}}
                        />
                    </Card>

                    <Card
                        bordered={false}
                        style={{
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                            borderRadius: '12px'
                        }}
                        bodyStyle={{padding: 0}}
                    >
                        {loading ? (
                            <div style={{padding: 24, textAlign: 'center'}}>
                                <Spin tip="Загрузка данных..." size="large"/>
                            </div>
                        ) : (
                            <List
                                itemLayout="horizontal"
                                dataSource={issues.sort((a, b) => dayjs(b.timestamp).diff(dayjs(a.timestamp)))}
                                renderItem={(item) => (
                                    <List.Item
                                        onClick={() => handleIssueClick(item)}
                                        style={{
                                            cursor: 'pointer',
                                            padding: '16px 24px',
                                            borderBottom: '1px solid #f0f0f0',
                                            transition: 'all 0.3s',
                                            ':hover': {
                                                backgroundColor: '#fafafa',
                                                boxShadow: '0 2px 8px rgba(138, 43, 226, 0.2)'
                                            }
                                        }}
                                    >
                                        <List.Item.Meta
                                            title={
                                                <div style={{display: 'flex', alignItems: 'center'}}>
                                                    <Text strong style={{fontSize: '1.1rem', marginRight: 8}}>
                                                        {item.exception_type}
                                                    </Text>
                                                    <Tag
                                                        color={getSeverityColor(item.severity)}
                                                        style={{
                                                            borderRadius: '4px',
                                                            borderWidth: '0px'
                                                        }}
                                                    >
                                                        {item.severity}
                                                    </Tag>
                                                </div>
                                            }
                                            description={
                                                <div>
                                                    <Text type="secondary" style={{fontSize: '0.9rem'}}>
                                                        {item.exception_message}
                                                    </Text>
                                                    <div style={{marginTop: 4}}>
                                                        <Text type="secondary" style={{fontSize: '0.8rem'}}>
                                                            {dayjs(item.timestamp).format('DD.MM.YYYY HH:mm')} • {item.path}:{item.line} • {item.operation_system}
                                                        </Text>
                                                    </div>
                                                </div>
                                            }
                                        />
                                    </List.Item>
                                )}
                            />
                        )}
                    </Card>

                    <Modal
                        title={
                            <div>
                                <Text strong style={{fontSize: '1.2rem'}}>{selectedIssue?.exception_type}</Text>
                                <Tag
                                    color={selectedIssue ? getSeverityColor(selectedIssue.severity) : 'blue'}
                                    style={{marginLeft: 8, borderRadius: '4px', borderWidth: '0px'}}
                                >
                                    {selectedIssue?.severity}
                                </Tag>
                            </div>
                        }
                        visible={isModalVisible}
                        onCancel={handleCloseModal}
                        footer={null}
                        width={800}
                        centered
                        bodyStyle={{padding: 24}}
                    >
                        {selectedIssue && (
                            <div>
                                <div style={{
                                    maxHeight: '300px',
                                    overflowY: 'auto',
                                    padding: '10px',
                                    marginBottom: '20px',
                                    border: '1px solid #f0f0f0',
                                    borderRadius: '8px'
                                }}>
                                    <SyntaxHighlighter
                                        language="python"
                                        style={oneLight}
                                        showLineNumbers={true}
                                        wrapLines={true}
                                        lineProps={(lineNumber) => ({
                                            style: {
                                                display: "block",
                                                backgroundColor: lineNumber === selectedIssue.line ? "#f6e6ff" : "transparent",
                                                padding: "4px 0",
                                            },
                                        })}
                                    >
                                        {selectedIssue.content}
                                    </SyntaxHighlighter>
                                </div>

                                <Descriptions bordered column={1} size="middle">
                                    <Descriptions.Item label="Дата">
                                        {dayjs(selectedIssue.timestamp).format('DD.MM.YYYY HH:mm')}
                                    </Descriptions.Item>
                                    <Descriptions.Item label="Функция">{selectedIssue.function}</Descriptions.Item>
                                    <Descriptions.Item label="Путь">{selectedIssue.path}</Descriptions.Item>
                                    <Descriptions.Item label="Номер строки">{selectedIssue.line}</Descriptions.Item>
                                    <Descriptions.Item
                                        label="Тип ошибки">{selectedIssue.exception_type}</Descriptions.Item>
                                    <Descriptions.Item
                                        label="Сообщение ошибки">{selectedIssue.exception_message}</Descriptions.Item>
                                    <Descriptions.Item
                                        label="Версия Python">{selectedIssue.python_version}</Descriptions.Item>
                                    <Descriptions.Item label="ОС">{selectedIssue.operation_system}</Descriptions.Item>
                                </Descriptions>
                            </div>
                        )}
                    </Modal>
                </div>
            </div>
        </ConfigProvider>
    );
}