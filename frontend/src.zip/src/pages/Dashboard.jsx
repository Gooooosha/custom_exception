import {useEffect, useState} from 'react';
import {Card, Col, ConfigProvider, Row, Spin, Statistic, Typography} from 'antd';
import Aside from "../components/Aside.jsx";
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';
import dayjs from 'dayjs';
import {
    ArrowUpOutlined,
    ArrowDownOutlined,
    BarChartOutlined,
    LineChartOutlined,
    PieChartOutlined
} from '@ant-design/icons';

const {Title, Text} = Typography;

export default function Dashboard() {
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalUsers: 0,
        activeUsers: 0,
        newUsers: 0,
        retentionRate: 0
    });

    useEffect(() => {
        setTimeout(() => {
            // Генерация тестовых данных
            setStats({
                totalUsers: 15432,
                activeUsers: 8432,
                newUsers: 324,
                retentionRate: 78.5
            });
            setLoading(false);
        }, 1000);
    }, []);

    const generateUserActivityData = () => {
        const days = [];
        const activeUsers = [];
        const newUsers = [];

        for (let i = 14; i >= 0; i--) {
            const date = dayjs().subtract(i, 'day').format('DD.MM');
            days.push(date);
            activeUsers.push(Math.floor(Math.random() * 500) + 7000);
            newUsers.push(Math.floor(Math.random() * 100) + 200);
        }

        return {days, activeUsers, newUsers};
    };

    const generateDeviceDistribution = () => {
        return [
            {value: 65, name: 'Desktop'},
            {value: 25, name: 'Mobile'},
            {value: 10, name: 'Tablet'}
        ];
    };

    const generateTrafficSources = () => {
        return [
            {value: 45, name: 'Organic'},
            {value: 25, name: 'Direct'},
            {value: 15, name: 'Social'},
            {value: 10, name: 'Referral'},
            {value: 5, name: 'Email'}
        ];
    };

    const {days, activeUsers, newUsers} = generateUserActivityData();
    const deviceData = generateDeviceDistribution();
    const trafficData = generateTrafficSources();

    const activityChartOption = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        legend: {
            data: ['Active Users', 'New Users'],
            right: 10,
            top: 0
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: days,
            axisLabel: {
                color: '#666'
            },
            axisLine: {
                lineStyle: {
                    color: '#ddd'
                }
            }
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                color: '#666'
            },
            axisLine: {
                show: false
            },
            splitLine: {
                lineStyle: {
                    color: '#f0f0f0'
                }
            }
        },
        series: [
            {
                name: 'Active Users',
                type: 'line',
                smooth: true,
                showSymbol: false,
                data: activeUsers,
                lineStyle: {
                    width: 3,
                    color: '#8A2BE2'
                },
                itemStyle: {
                    color: '#8A2BE2'
                },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {offset: 0, color: 'rgba(138, 43, 226, 0.3)'},
                        {offset: 1, color: 'rgba(138, 43, 226, 0.1)'}
                    ])
                }
            },
            {
                name: 'New Users',
                type: 'bar',
                barWidth: '40%',
                data: newUsers,
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {offset: 0, color: '#722ED1'},
                        {offset: 1, color: '#B37FEB'}
                    ]),
                    borderRadius: [4, 4, 0, 0]
                }
            }
        ]
    };

    const deviceChartOption = {
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            right: 10,
            top: 'center'
        },
        series: [
            {
                name: 'Devices',
                type: 'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 4,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '18',
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: deviceData,
                color: ['#8A2BE2', '#B37FEB', '#D3ADF7']
            }
        ]
    };

    const trafficChartOption = {
        tooltip: {
            trigger: 'item'
        },
        series: [
            {
                name: 'Traffic Sources',
                type: 'pie',
                radius: '70%',
                center: ['50%', '50%'],
                data: trafficData,
                itemStyle: {
                    borderRadius: 4,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    formatter: '{b}: {d}%'
                },
                color: ['#722ED1', '#9254DE', '#B37FEB', '#D3ADF7', '#EFDBFF']
            }
        ]
    };

    return (
        <ConfigProvider
            theme={{
                token: {
                    colorPrimary: '#8A2BE2',
                    colorTextPlaceholder: '#777777',
                },
                components: {
                    Menu: {
                        darkItemSelectedBg: 'rgb(103,40,156)',
                    },
                    Button: {
                        defaultHoverBg: '#f6e6ff',
                        defaultHoverColor: '#8A2BE2',
                        defaultHoverBorderColor: '#8A2BE2',
                    },
                    Card: {
                        borderRadiusLG: 12,
                    },
                },
            }}
        >
            <div style={{display: 'flex', minHeight: '100vh', backgroundColor: '#f5f5f5'}}>
                <Aside/>
                <div style={{marginLeft: 350, padding: 24, width: '100%'}}>
                    {loading ? (
                        <Spin tip="Загрузка данных..." size="large"/>
                    ) : (
                        <>
                            <Title level={2} style={{color: '#2c3959', marginBottom: 24}}>
                                <LineChartOutlined style={{marginRight: 12}}/>
                                Аналитика приложения
                            </Title>

                            <Row gutter={[24, 24]} style={{marginBottom: 24}}>
                                <Col xs={24} sm={12} md={6}>
                                    <Card bordered={false} style={{boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)'}}>
                                        <Statistic
                                            title="Всего пользователей"
                                            value={stats.totalUsers}
                                            prefix={<BarChartOutlined/>}
                                            valueStyle={{color: '#8A2BE2'}}
                                        />
                                    </Card>
                                </Col>
                                <Col xs={24} sm={12} md={6}>
                                    <Card bordered={false} style={{boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)'}}>
                                        <Statistic
                                            title="Активных сегодня"
                                            value={stats.activeUsers}
                                            prefix={<ArrowUpOutlined/>}
                                            valueStyle={{color: '#52c41a'}}
                                        />
                                    </Card>
                                </Col>
                                <Col xs={24} sm={12} md={6}>
                                    <Card bordered={false} style={{boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)'}}>
                                        <Statistic
                                            title="Новых пользователей"
                                            value={stats.newUsers}
                                            prefix={<ArrowUpOutlined/>}
                                            valueStyle={{color: '#52c41a'}}
                                        />
                                    </Card>
                                </Col>
                                <Col xs={24} sm={12} md={6}>
                                    <Card bordered={false} style={{boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)'}}>
                                        <Statistic
                                            title="Retention Rate"
                                            value={stats.retentionRate}
                                            suffix="%"
                                            prefix={<ArrowDownOutlined/>}
                                            valueStyle={{color: '#f5222d'}}
                                        />
                                    </Card>
                                </Col>
                            </Row>

                            <Card
                                title={
                                    <Text strong style={{fontSize: 16}}>
                                        <LineChartOutlined style={{marginRight: 8}}/>
                                        Активность пользователей (14 дней)
                                    </Text>
                                }
                                bordered={false}
                                style={{
                                    marginBottom: 24,
                                    boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)',
                                    borderRadius: 12
                                }}
                            >
                                <ReactECharts
                                    option={activityChartOption}
                                    style={{height: 400}}
                                    theme="light"
                                    opts={{renderer: 'svg'}}
                                />
                            </Card>

                            <Row gutter={[24, 24]}>
                                <Col xs={24} md={12}>
                                    <Card
                                        title={
                                            <Text strong style={{fontSize: 16}}>
                                                <PieChartOutlined style={{marginRight: 8}}/>
                                                Устройства пользователей
                                            </Text>
                                        }
                                        bordered={false}
                                        style={{
                                            boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)',
                                            borderRadius: 12
                                        }}
                                    >
                                        <ReactECharts
                                            option={deviceChartOption}
                                            style={{height: 300}}
                                            theme="light"
                                            opts={{renderer: 'svg'}}
                                        />
                                    </Card>
                                </Col>
                                <Col xs={24} md={12}>
                                    <Card
                                        title={
                                            <Text strong style={{fontSize: 16}}>
                                                <PieChartOutlined style={{marginRight: 8}}/>
                                                Источники трафика
                                            </Text>
                                        }
                                        bordered={false}
                                        style={{
                                            boxShadow: '0 1px 2px 0 rgba(0,0,0,0.03)',
                                            borderRadius: 12
                                        }}
                                    >
                                        <ReactECharts
                                            option={trafficChartOption}
                                            style={{height: 300}}
                                            theme="light"
                                            opts={{renderer: 'svg'}}
                                        />
                                    </Card>
                                </Col>
                            </Row>
                        </>
                    )}
                </div>
            </div>
        </ConfigProvider>
    );
}