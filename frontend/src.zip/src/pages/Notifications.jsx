import {useEffect, useState} from 'react';
import {Button, Card, ConfigProvider, Divider, Form, Input, List, message, Modal, Select, Tag, Typography} from 'antd';
import {DeleteOutlined, PlusOutlined} from '@ant-design/icons';
import axios from 'axios';
import Aside from '../components/Aside';

const {Option} = Select;
const {Text} = Typography;

const notificationTypes = [
    {value: 'webhook', label: 'Webhook'},
    {value: 'mattermost', label: 'Mattermost'},
    {value: 'slack', label: 'Slack'}
];

const Notifications = () => {
    const [form] = Form.useForm();
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [selectedType, setSelectedType] = useState('webhook');
    const [messageApi, contextHolder] = message.useMessage();

    useEffect(() => {
        fetchNotifications();
    }, []);

    const fetchNotifications = async () => {
        setLoading(true);
        try {
            const response = await axios.get('http://127.0.0.1:8006/api/notifications');
            setNotifications(response.data);
        } catch (error) {
            messageApi.error('Ошибка при загрузке уведомлений');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (values) => {
        try {
            await axios.post('/api/notifications', values);
            messageApi.success('Уведомление успешно добавлено');
            handleModalClose();
            fetchNotifications();
        } catch (error) {
            messageApi.error('Ошибка при добавлении уведомления');
        }
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`/api/notifications/${id}`);
            messageApi.success('Уведомление удалено');
            fetchNotifications();
        } catch (error) {
            messageApi.error('Ошибка при удалении уведомления');
        }
    };

    const handleModalClose = () => {
        form.resetFields();
        setSelectedType('webhook'); // Сбрасываем тип к значению по умолчанию
        setIsModalVisible(false);
    };

    const renderTypeSpecificFields = () => {
        switch (selectedType) {
            case 'webhook':
                return (
                    <Form.Item
                        label="URL webhook"
                        name="webhookUrl"
                        rules={[{required: true, message: ''}]}
                    >
                        <Input style={{height: '45px', borderRadius: '8px'}} placeholder="https://example.com/webhook"/>
                    </Form.Item>
                );
            case 'mattermost':
                return (
                    <>
                        <Form.Item
                            label="URL Mattermost"
                            name="mattermostUrl"
                            rules={[{required: true, message: ''}]}
                        >
                            <Input style={{height: '45px', borderRadius: '8px'}}
                                   placeholder="https://mattermost.example.com"/>
                        </Form.Item>
                        <Form.Item
                            label="Канал"
                            name="channel"
                            rules={[{required: true, message: ''}]}
                        >
                            <Input style={{height: '45px', borderRadius: '8px'}} placeholder="general"/>
                        </Form.Item>
                        <Form.Item
                            label="Имя пользователя"
                            name="username"
                            rules={[{required: true, message: ''}]}
                        >
                            <Input style={{height: '45px', borderRadius: '8px'}} placeholder="bot"/>
                        </Form.Item>
                    </>
                );
            case 'slack':
                return (
                    <Form.Item
                        label="Webhook URL Slack"
                        name="slackWebhookUrl"
                        rules={[{required: true, message: ''}]}
                    >
                        <Input style={{height: '45px', borderRadius: '8px'}}
                               placeholder="https://hooks.slack.com/services/..."/>
                    </Form.Item>
                );
            default:
                return null;
        }
    };

    const getTypeLabel = (type) => {
        const found = notificationTypes.find(t => t.value === type);
        return found ? found.label : type;
    };

    return (
        <ConfigProvider
            theme={{
                token: {
                    colorPrimary: '#8A2BE2',
                    colorTextPlaceholder: '#777777',
                },
                components: {
                    Menu: {
                        darkItemSelectedBg: 'rgb(103,40,156)',
                    },
                    Button: {
                        defaultHoverBg: '#f6e6ff',
                        defaultHoverColor: '#8A2BE2',
                        defaultHoverBorderColor: '#8A2BE2',
                    },
                    Card: {
                        borderRadiusLG: 12,
                    },
                },
            }}
        >
            {contextHolder}
            <div style={{display: 'flex', minHeight: '100vh', backgroundColor: '#f5f5f5'}}>
                <Aside/>
                <div style={{marginLeft: 350, padding: 24, width: '100%'}}>
                    <Card
                        title={
                            <span style={{
                                fontSize: '1.5rem',
                                color: '#2c3959',
                                fontWeight: 'bold'
                            }}>
                                Уведомления
                            </span>
                        }
                        extra={
                            <Button
                                type="primary"
                                icon={<PlusOutlined/>}
                                onClick={() => setIsModalVisible(true)}
                                style={{
                                    backgroundColor: '#8A2BE2',
                                    borderRadius: '8px',
                                    height: '40px'
                                }}
                            >
                                Добавить уведомление
                            </Button>
                        }
                        bordered={false}
                        style={{
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                            borderRadius: '12px'
                        }}
                    >
                        <List
                            loading={loading}
                            dataSource={notifications}
                            renderItem={(item) => (
                                <List.Item
                                    actions={[
                                        <Button
                                            danger
                                            icon={<DeleteOutlined/>}
                                            onClick={() => handleDelete(item.id)}
                                            style={{borderRadius: '8px'}}
                                        />
                                    ]}
                                    style={{
                                        padding: '16px',
                                        borderRadius: '8px',
                                        marginBottom: '8px',
                                        backgroundColor: '#ffffff',
                                        transition: 'all 0.3s',
                                        ':hover': {
                                            boxShadow: '0 2px 8px rgba(138, 43, 226, 0.2)'
                                        }
                                    }}
                                >
                                    <List.Item.Meta
                                        title={
                                            <div style={{display: 'flex', alignItems: 'center'}}>
                                                <Text strong style={{fontSize: '1.1rem'}}>{item.name}</Text>
                                                <Tag
                                                    color="blue"
                                                    style={{
                                                        marginLeft: 8,
                                                        backgroundColor: '#8A2BE2',
                                                        color: '#fff',
                                                        borderRadius: '4px',
                                                        borderWidth: '0px'
                                                    }}
                                                >
                                                    {getTypeLabel(item.type)}
                                                </Tag>
                                            </div>
                                        }
                                        description={
                                            <Text type="secondary" style={{fontSize: '0.9rem'}}>
                                                {item.description}
                                            </Text>
                                        }
                                    />
                                    <div>
                                        {item.type === 'webhook' && <Text code>{item.webhookUrl}</Text>}
                                        {item.type === 'mattermost' && (
                                            <>
                                                <Text code>{item.mattermostUrl}</Text>
                                                <Text>
                                                    / {item.channel} / {item.username}
                                                </Text>
                                            </>
                                        )}
                                        {item.type === 'slack' && <Text code>{item.slackWebhookUrl}</Text>}
                                    </div>
                                </List.Item>
                            )}
                        />
                    </Card>

                    <Modal
                        visible={isModalVisible}
                        onCancel={handleModalClose}
                        footer={null}
                        width={600}
                        centered
                        bodyStyle={{padding: '24px'}}
                    >
                        <Form
                            form={form}
                            layout="vertical"
                            onFinish={handleSubmit}
                            initialValues={{type: 'webhook'}}
                        >
                            <h1 style={{
                                fontSize: '2rem',
                                color: '#2c3959',
                                fontWeight: 'bold',
                                marginBottom: '20px',
                                textAlign: 'center'
                            }}>Добавить новое уведомление</h1>
                            <Form.Item
                                label={<span style={{fontWeight: '500'}}>Название</span>}
                                name="name"
                                rules={[{required: true, message: ''}]}
                            >
                                <Input
                                    placeholder="Мое уведомление"
                                    style={{height: '45px', borderRadius: '8px'}}
                                />
                            </Form.Item>

                            <Form.Item
                                label={<span style={{fontWeight: '500'}}>Описание</span>}
                                name="description"
                            >
                                <Input.TextArea
                                    rows={2}
                                    placeholder="Описание уведомления"
                                    style={{borderRadius: '8px'}}
                                />
                            </Form.Item>

                            <Form.Item
                                label={<span style={{fontWeight: '500'}}>Тип уведомления</span>}
                                name="type"
                                rules={[{required: true, message: ''}]}
                            >
                                <Select
                                    onChange={(value) => setSelectedType(value)}
                                    style={{height: '45px', borderRadius: '8px'}}
                                >
                                    {notificationTypes.map(type => (
                                        <Option key={type.value} value={type.value}>
                                            {type.label}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>

                            {renderTypeSpecificFields()}

                            <Divider/>

                            <Form.Item>
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                    style={{
                                        width: '100%',
                                        height: '45px',
                                        borderRadius: '8px',
                                        backgroundColor: '#8A2BE2',
                                        fontSize: '1rem'
                                    }}
                                >
                                    Сохранить
                                </Button>
                            </Form.Item>
                        </Form>
                    </Modal>
                </div>
            </div>
        </ConfigProvider>
    );
};

export default Notifications;