import {Button, ConfigProvider, Menu, Modal, Typography} from 'antd';
import {useState} from 'react';
import {useLocation, useNavigate} from "react-router-dom";
import {BugOutlined, DashboardOutlined, SendOutlined} from "@ant-design/icons";

const Aside = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [modalVisible, setModalVisible] = useState(false);
    const [userId, setUserId] = useState(null);
    const {Text, Link} = Typography;

    const items = [
        {
            key: 'profile',
            label: 'Георгий',
        },
        {
            key: 'issues',
            icon: <BugOutlined/>,
            label: 'Инциденты',
        },
        {
            key: 'dashboard',
            icon: <DashboardOutlined/>,
            label: 'Аналитика',
        },
        {
            key: 'notifications',
            icon: <SendOutlined/>,
            label: 'Уведомления',
        },
    ];

    const onClick = (e) => {
        switch (e.key) {
            case 'issues':
                navigate('/issues');
                break;
            case 'notifications':
                navigate('/notifications');
                break;
            case 'dashboard':
                navigate('/dashboard');
                break;
            case 'profile':
                setModalVisible(true);
                setUserId('234654937');
                break;
            default:
                break;
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
    };

    // Determine selected key based on current route
    const selectedKey = location.pathname === '/dashboard' ? 'dashboard' :
        location.pathname === '/issues' ? 'issues' :
            location.pathname === '/notifications' ? 'notifications' : '';

    return (
        <>
            <div style={{height: '100vh'}}>
                <ConfigProvider
                    theme={{
                        components: {
                            Menu: {
                                darkItemSelectedBg: 'rgb(103,40,156)',
                            },
                        },
                    }}
                >
                    <Menu
                        selectedKeys={[selectedKey]}
                        mode="vertical"
                        theme="dark"
                        items={items}
                        onClick={onClick}
                        style={{
                            height: '100%',
                            position: 'fixed',
                            left: 0,
                            top: 0,
                            width: '350px',
                        }}
                    />
                </ConfigProvider>
            </div>

            <Modal
                open={modalVisible}
                onCancel={handleModalClose}
                footer={[
                    <Button key="close" onClick={handleModalClose}>
                        Закрыть
                    </Button>,
                ]}
            >
                <h1>DSN</h1>
                <Text code>{userId}</Text>
            </Modal>
        </>
    );
};

export default Aside;