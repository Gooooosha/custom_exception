import {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';

export default function PrivateRoute({children}) {
    const [loading, setLoading] = useState(true);
    const [authorized, setAuthorized] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://127.0.0.1:8006/api/me', { withCredentials: true })
            .then(() => {
                setAuthorized(true);
                setLoading(false);
            })
            .catch(() => {
                navigate('/');
            });
    }, []);

    if (loading) return null; // или лоадер

    return authorized ? children : null;
}
