import {Route, Routes} from "react-router-dom";
import Issues from "./pages/Issues.jsx";
import Authentication from "./pages/Authentication.jsx";
import PrivateRoute from "./components/PrivateRoute.jsx";
import {Result} from "antd";
import {FrownOutlined} from "@ant-design/icons";
import Notifications from "./pages/Notifications.jsx";
import Dashboard from "./pages/Dashboard.jsx";

export default function App() {
    return (
        <Routes>
            <Route path="/" element={<Authentication />} />
            <Route path="/issues" element={
                <PrivateRoute>
                    <Issues />
                </PrivateRoute>
            } />
            <Route path="/notifications" element={
                <PrivateRoute>
                    <Notifications />
                </PrivateRoute>
            } />
            <Route path="/dashboard" element={
                <PrivateRoute>
                    <Dashboard />
                </PrivateRoute>
            } />
            <Route path="*" element={
                <div style={{
                    backgroundColor: '#2e2e2e',
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                }}>
                    <Result
                        icon={<FrownOutlined style={{ fontSize: '120px', color: '#e8aa0e' }} />}
                        title={<span style={{ color: '#fff' }}>404</span>}
                        subTitle={<span style={{ color: '#aaa' }}>Страница не найдена...</span>}
                    />
                </div>
            } />
        </Routes>
    );
}